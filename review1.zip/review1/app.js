// app.js

const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const User = require('./models/User'); // Import User model
const Business = require('./models/business'); // Import Business model
const bodyParser = require('body-parser');
const session = require('express-session');
const fetch = require("node-fetch");

const app = express();
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Set up express-session
app.use(session({
    secret: 'your_secret_key',
    resave: false,
    saveUninitialized: true
}));

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/userAuthDB', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log('MongoDB connected');
}).catch((err) => {
    console.log('MongoDB connection error: ', err);
});

// Set EJS as the templating engine
app.set('view engine', 'ejs');

// Simple Home route
app.get('/', (req, res) => {
    res.render('home'); // Assumes you have a home.ejs file
});

// Register route
app.get('/register', (req, res) => {
    res.render('register'); // Render the registration form (register.ejs)
});

// Handle registration
app.post('/register', async (req, res) => {
    const { username, email, password } = req.body;

    // Hash the password before storing it
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create a new user
    const newUser = new User({
        username: username,
        email: email,
        password: hashedPassword
    });

    try {
        await newUser.save();
        res.redirect('/login'); // Redirect to the login page after successful registration
    } catch (err) {
        res.status(500).send('Error registering user: ' + err.message);
    }
});

// Login route
app.get('/login', (req, res) => {
    res.render('login'); // Render the login form (login.ejs)
});

// Handle login
app.post('/login', async (req, res) => {
    const { email, password } = req.body;

    // Find the user by email
    const user = await User.findOne({ email: email });

    if (!user) {
        return res.status(400).send('User not found');
    }

    // Compare the password
    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
        return res.status(400).send('Invalid password');
    }

    // Set session variables (you can store user ID or name here)
    req.session.userId = user._id;
    req.session.username = user.username;

    // Redirect to landing page after successful login
    res.redirect('/landing');
});

// Protected landing page route to display ads after login
app.get('/landing', async (req, res) => {
    if (!req.session.userId) {
        return res.redirect('/login'); // Redirect to login if not authenticated
    }

    try {
        // Fetch all ads from the database
        const ads = await Business.find({});
        res.render('landing', { username: req.session.username, ads: ads }); // Render landing.ejs and pass ads data
    } catch (err) {
        res.status(500).send('Error fetching ads.');
    }
});

// Submit Ads route (GET: renders the submission form)
app.get('/submitads', (req, res) => {
    if (!req.session.userId) {
        return res.redirect('/login'); // Redirect to login if not authenticated
    }
    res.render('submitads'); // Render submitads.ejs for users to submit their business ads
});

// Handle Ad submission (POST: saves the ad to the database)
app.post('/submitads', async (req, res) => {
    const { title, description, contactInfo } = req.body;

    const newAd = new Business({
        title: title,
        description: description,
        contactInfo: contactInfo
    });

    try {
        await newAd.save(); // Save the ad to the database
        res.redirect('/landing'); // Redirect back to the landing page after submission
    } catch (err) {
        res.status(500).send('Error submitting ad: ' + err.message);
    }
});

// Logout route
app.post('/logout', (req, res) => {
    req.session.destroy(); // Destroy the session
    res.redirect('/login');
});

// Add this to your existing app.js
app.get('/webhook', (req, res) => {
    const verifyToken = req.query['hub.verify_token'];

    // This token should match the verify token you provide in Facebook Developer
    if (verifyToken === 'bizConnectChat') {
        res.status(200).send(req.query['hub.challenge']); // Respond with the challenge token
    } else {
        res.sendStatus(403); // Forbidden
    }
});

app.get('/bizzy', (req, res) => {
    res.render('bizzy', { welcomeMessage: "Hello! Welcome to BizConnect. How can I assist you today?" });
});

const WIT_SERVER_TOKEN = 'MVVB52F3KTUHJ7JS4QO4M4BRSN6GR4NL';

app.post("/bizzy", async (req, res) => {
    const userMessage = req.body.message;

    try {
        const witResponse = await fetch(`https://api.wit.ai/message?v=20230401&q=${encodeURIComponent(userMessage)}`, {
            headers: {
                Authorization: `Bearer ${WIT_SERVER_TOKEN}`, // Ensure this is the correct token
            },
        });

        const witData = await witResponse.json();
        
        // Log the full response from Wit.ai
        console.log('Wit.ai response:', witData);

        // Extract intent and entities
        const intent = witData.intents[0]?.name || null;
        const entities = witData.entities || {};

        // Define responses based on intents and entities
        let reply;
        if (intent === "advertisement_tips") {
            reply = "Here are some ideas for making advertisements for your business: Try engaging storytelling, include customer testimonials, or create promotional offers!";
        } else if (intent === "about_website") {
            reply = "Our website connects local businesses with users by allowing businesses to post advertisements, share promotions, and interact through comments and messages.";
        } else if (intent === "greeting") {
            reply = "Hello! Welcome to BizConnect. How can I assist you today?";
        } else if (intent === "advertising_tips" && entities["ad_type"]) {
            const adType = entities["ad_type"][0].value;
            reply = `For ${adType} advertisements, focus on visual appeal and clear messaging to attract your target audience.`;
        } else {
            reply = "I'm here to help! Feel free to ask questions about our platform or advertising tips.";
        }

        // Send the reply in text format
        res.send(reply);
    } catch (error) {
        console.error("Error communicating with Wit.ai:", error);
        res.status(500).send("There was an error processing your request.");
    }
});


  

app.listen(3000, () => {
    console.log('Server started on http://localhost:3000');
});
